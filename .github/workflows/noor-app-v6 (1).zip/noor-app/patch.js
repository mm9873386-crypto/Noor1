// يُشغَّل تلقائياً أثناء البناء: ينسخ أصوات الأذان، يضيف الصلاحيات، ويثبّت خدمة الأذان الأصلية (تعمل في الخلفية)
const fs = require("fs");
const path = require("path");

// 1) أصوات الأذان
const raw = "android/app/src/main/res/raw";
fs.mkdirSync(raw, { recursive: true });
fs.readdirSync("android-res/raw").forEach(f => fs.copyFileSync("android-res/raw/" + f, raw + "/" + f));

// 2) ملفات Java الخاصة بالأذان (خدمة + منبّه + إضافة Capacitor)
const appId = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8")).appId;
const javaDir = path.join("android/app/src/main/java", ...appId.split("."));
fs.mkdirSync(javaDir, { recursive: true });
fs.readdirSync("android-src").filter(f => f.endsWith(".java")).forEach(f => {
  const src = fs.readFileSync(path.join("android-src", f), "utf8").split("__PKG__").join(appId);
  fs.writeFileSync(path.join(javaDir, f), src);
});

// 3) AndroidManifest: الصلاحيات + الخدمة + المستقبِلات
const mf = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(mf, "utf8");
["POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "USE_EXACT_ALARM", "RECEIVE_BOOT_COMPLETED", "ACCESS_FINE_LOCATION",
 "ACCESS_COARSE_LOCATION", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_MEDIA_PLAYBACK", "WAKE_LOCK", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"].forEach(p => {
  if (!x.includes('android.permission.' + p + '"'))
    x = x.replace("<application", '<uses-permission android:name="android.permission.' + p + '"/><application');
});
if (!x.includes("AdhanService")) {
  const comps =
    '<service android:name="' + appId + '.AdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>' +
    '<receiver android:name="' + appId + '.AdhanReceiver" android:exported="false"/>' +
    '<receiver android:name="' + appId + '.AdhanBootReceiver" android:exported="true"><intent-filter>' +
    '<action android:name="android.intent.action.BOOT_COMPLETED"/>' +
    '<action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>' +
    '<action android:name="android.intent.action.TIME_SET"/>' +
    '<action android:name="android.intent.action.TIMEZONE_CHANGED"/>' +
    '</intent-filter></receiver>';
  x = x.replace("</application>", comps + "</application>");
}
fs.writeFileSync(mf, x);
console.log("patched");

package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class AdhanReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null) return;
        if (a.equals(AdhanService.ACT_STOP)) {
            c.stopService(new Intent(c, AdhanService.class));
            return;
        }
        if (a.equals(AdhanScheduler.ACT)) {
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("title", in.getStringExtra("title"));
            s.putExtra("body", in.getStringExtra("body"));
            s.putExtra("sound", in.getStringExtra("sound"));
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    c.startForegroundService(s);
                } else {
                    c.startService(s);
                }
            } catch (Exception e) {
                // ignore
            }
        }
    }
}

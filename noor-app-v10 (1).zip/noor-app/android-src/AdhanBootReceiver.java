package __PKG__;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AdhanBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        AdhanScheduler.apply(c);
    }
}

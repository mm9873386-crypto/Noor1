package __PKG__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;

public class AdhanService extends Service {
    static final String ACT_STOP = "__PKG__.ADHAN_STOP";
    static final String CH = "noor_adhan_v2";
    static final int NID = 4711;
    private MediaPlayer mp;

    @Override
    public IBinder onBind(Intent i) {
        return null;
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        String title = in != null ? in.getStringExtra("title") : null;
        String body = in != null ? in.getStringExtra("body") : null;
        String sound = in != null ? in.getStringExtra("sound") : null;
        if (title == null) title = "حان وقت الصلاة";
        if (body == null) body = "";
        if (sound == null) sound = "adhan0";

        ensureChannel(this);
        Notification n = buildNotification(title, body);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NID, n);
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAudio(sound);
        return START_NOT_STICKY;
    }

    static void ensureChannel(android.content.Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CH, "الأذان", NotificationManager.IMPORTANCE_HIGH);
            ch.setSound(null, null);
            ch.enableVibration(false);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification(String title, String body) {
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;

        PendingIntent openPi = null;
        Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (open != null) openPi = PendingIntent.getActivity(this, 0, open, f);

        Intent stop = new Intent(this, AdhanReceiver.class);
        stop.setAction(ACT_STOP);
        PendingIntent stopPi = PendingIntent.getBroadcast(this, 1, stop, f);

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CH)
                .setSmallIcon(AdhanReceiver.icon(this))
                .setColor(AdhanReceiver.GREEN)
                .setLargeIcon(AdhanReceiver.largeIcon(this))
                .setTicker(title)
                .setWhen(System.currentTimeMillis())
                .setShowWhen(true)
                .setContentTitle(title)
                .setContentText(body)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .addAction(AdhanReceiver.res(this, "ic_act_stop", 0), "إيقاف الأذان", stopPi);
        if (Build.VERSION.SDK_INT >= 31) b.setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE);
        if (openPi != null) b.setContentIntent(openPi);
        return b.build();
    }

    private void startAudio(String sound) {
        releasePlayer();
        try {
            int res = getResources().getIdentifier(sound, "raw", getPackageName());
            if (res == 0) {
                stopSelf();
                return;
            }
            mp = new MediaPlayer();
            AssetFileDescriptor afd = getResources().openRawResourceFd(res);
            mp.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            mp.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    stopSelf();
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    stopSelf();
                    return true;
                }
            });
            mp.prepare();
            mp.start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void releasePlayer() {
        if (mp != null) {
            try {
                mp.stop();
            } catch (Exception e) {
                // ignore
            }
            mp.release();
            mp = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        stopForeground(true);
        super.onDestroy();
    }
}

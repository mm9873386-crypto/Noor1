package __PKG__;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "Adhan")
public class AdhanPlugin extends Plugin {

    @PluginMethod
    public void schedule(PluginCall call) {
        JSArray items = call.getArray("items");
        if (items == null) {
            call.reject("no items");
            return;
        }
        AdhanService.ensureChannel(getContext());
        getContext().getSharedPreferences(AdhanScheduler.PREFS, 0)
                .edit().putString("items", items.toString()).apply();
        AdhanScheduler.apply(getContext());
        call.resolve();
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getContext().stopService(new Intent(getContext(), AdhanService.class));
        call.resolve();
    }

    @PluginMethod
    public void status(PluginCall call) {
        Context c = getContext();
        AdhanService.ensureChannel(c);
        JSObject r = new JSObject();
        r.put("notif", NotificationManagerCompat.from(c).areNotificationsEnabled());

        boolean chOk = true;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                NotificationChannel ch = nm.getNotificationChannel(AdhanService.CH);
                if (ch != null && ch.getImportance() == NotificationManager.IMPORTANCE_NONE) chOk = false;
            }
        }
        r.put("channel", chOk);

        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am != null) exact = am.canScheduleExactAlarms();
        }
        r.put("exact", exact);

        boolean batt = true;
        if (Build.VERSION.SDK_INT >= 23) {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            batt = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        }
        r.put("battery", batt);
        call.resolve(r);
    }

    private void launch(Intent i) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        } catch (Exception e) {
            // ignore
        }
    }

    @PluginMethod
    public void openNotifSettings(PluginCall call) {
        Intent i = new Intent();
        if (Build.VERSION.SDK_INT >= 26) {
            i.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            i.putExtra(Settings.EXTRA_APP_PACKAGE, getContext().getPackageName());
        } else {
            i.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
        }
        launch(i);
        call.resolve();
    }

    @PluginMethod
    public void openBatterySettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
        i.setData(Uri.parse("package:" + getContext().getPackageName()));
        launch(i);
        call.resolve();
    }

    @PluginMethod
    public void openExactSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31) {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            i.setData(Uri.parse("package:" + getContext().getPackageName()));
            launch(i);
        }
        call.resolve();
    }

    @PluginMethod
    public void testAdhan(PluginCall call) {
        Integer sec = call.getInt("seconds", 10);
        int s = sec == null ? 10 : sec.intValue();
        AdhanService.ensureChannel(getContext());
        AdhanScheduler.scheduleOne(getContext(), 9999,
                System.currentTimeMillis() + s * 1000L,
                "تجربة الأذان", "إذا ظهر هذا الإشعار فالأذان يعمل", "adhan0");
        call.resolve();
    }

    @PluginMethod
    public void testFollow(PluginCall call) {
        Integer sec = call.getInt("seconds", 10);
        int s = sec == null ? 10 : sec.intValue();
        AdhanScheduler.scheduleOne(getContext(), 9998,
                System.currentTimeMillis() + s * 1000L,
                "هل صليت صلاتك الآن؟", "تجربة المتابعة", "", "follow");
        call.resolve();
    }
}

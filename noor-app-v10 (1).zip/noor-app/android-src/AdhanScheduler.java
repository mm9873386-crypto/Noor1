package __PKG__;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdhanScheduler {
    static final String ACT = "__PKG__.ADHAN_FIRE";
    static final String PREFS = "noor_adhan";

    static PendingIntent firePi(Context c, int id, String title, String body, String sound, String kind) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction(ACT);
        i.putExtra("title", title);
        i.putExtra("body", body);
        i.putExtra("sound", sound);
        i.putExtra("kind", kind);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, id, i, flags);
    }

    static void scheduleOne(Context c, int id, long at, String title, String body, String sound) {
        scheduleOne(c, id, at, title, body, sound, "adhan");
    }

    static void scheduleOne(Context c, int id, long at, String title, String body, String sound, String kind) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = firePi(c, id, title, body, sound, kind);
        boolean exact = true;
        if (Build.VERSION.SDK_INT >= 31) exact = am.canScheduleExactAlarms();
        try {
            if (exact) {
                if (Build.VERSION.SDK_INT >= 23) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                } else {
                    am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
                }
            } else {
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, null), pi);
            }
        } catch (SecurityException e) {
            am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, null), pi);
        }
    }

    static void apply(Context c) {
        try {
            SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;

            String old = sp.getString("ids", "");
            if (old.length() > 0) {
                String[] parts = old.split(",");
                for (int k = 0; k < parts.length; k++) {
                    if (parts[k].length() == 0) continue;
                    am.cancel(firePi(c, Integer.parseInt(parts[k]), "", "", "", ""));
                }
            }

            JSONArray arr = new JSONArray(sp.getString("items", "[]"));
            long now = System.currentTimeMillis();
            StringBuilder ids = new StringBuilder();

            for (int k = 0; k < arr.length(); k++) {
                JSONObject o = arr.getJSONObject(k);
                long at = o.getLong("at");
                if (at <= now) continue;
                int id = o.getInt("id");
                scheduleOne(c, id, at,
                        o.optString("title", "حان وقت الصلاة"),
                        o.optString("body", ""),
                        o.optString("sound", "adhan0"),
                        o.optString("kind", "adhan"));
                ids.append(id).append(",");
            }
            sp.edit().putString("ids", ids.toString()).apply();
        } catch (Exception e) {
            // ignore
        }
    }
}

// يُشغَّل تلقائياً أثناء البناء: ينسخ أصوات الأذان، يضيف الصلاحيات، ويثبّت خدمة الأذان الأصلية (تعمل في الخلفية)
const fs = require("fs");
const path = require("path");

// 1) أصوات الأذان
const raw = "android/app/src/main/res/raw";
fs.mkdirSync(raw, { recursive: true });
fs.readdirSync("android-res/raw").forEach(f => fs.copyFileSync("android-res/raw/" + f, raw + "/" + f));


// 1b) خط القرآن (Amiri Quran) من npm إلى www/fonts ليعمل دون إنترنت
try {
  const fsrc = "node_modules/@fontsource/amiri-quran/files";
  if (fs.existsSync(fsrc)) {
    fs.mkdirSync("www/fonts", { recursive: true });
    fs.readdirSync(fsrc).filter(f => f.includes("arabic-400-normal")).forEach(f => fs.copyFileSync(path.join(fsrc, f), path.join("www/fonts", f)));
    console.log("quran font copied");
  } else console.log("quran font package not found (will use fallback fonts)");
} catch (e) { console.log("font copy skipped", e.message); }

// 1c) أيقونة التطبيق (هلال ومسجد)
try {
  const isrc = "android-res/icons", res = "android/app/src/main/res";
  if (fs.existsSync(isrc)) {
    fs.readdirSync(isrc).forEach(d => {
      const to = path.join(res, d);
      fs.mkdirSync(to, { recursive: true });
      fs.readdirSync(path.join(isrc, d)).forEach(f => fs.copyFileSync(path.join(isrc, d, f), path.join(to, f)));
    });
    fs.mkdirSync(path.join(res, "values"), { recursive: true });
    fs.writeFileSync(path.join(res, "values/ic_launcher_background.xml"),
      '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0B5D45</color>\n</resources>\n');
    const adaptive = '<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n';
    fs.mkdirSync(path.join(res, "mipmap-anydpi-v26"), { recursive: true });
    fs.writeFileSync(path.join(res, "mipmap-anydpi-v26/ic_launcher.xml"), adaptive);
    fs.writeFileSync(path.join(res, "mipmap-anydpi-v26/ic_launcher_round.xml"), adaptive);
    console.log("icons copied");
  }
} catch (e) { console.log("icons skipped:", e.message); }

// 1d) أيقونة الإشعار الصغيرة (هلال أبيض)
try {
  const dr = "android/app/src/main/res/drawable";
  fs.mkdirSync(dr, { recursive: true });
  fs.writeFileSync(path.join(dr, "ic_stat_noor.xml"),
    '<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n    <path android:fillColor="#FFFFFF" android:pathData="M12,3a9,9 0,1 0,9 9c0,-0.46 -0.04,-0.92 -0.1,-1.36a5.389,5.389 0,0 1,-4.4 2.26a5.403,5.403 0,0 1,-3.14 -9.8c-0.44,-0.06 -0.9,-0.1 -1.36,-0.1z"/>\n</vector>\n');
  console.log("notif icon written");
} catch (e) { console.log("notif icon skipped:", e.message); }

// 2) ملفات Java الخاصة بالأذان (خدمة + منبّه + إضافة Capacitor)
const appId = JSON.parse(fs.readFileSync("capacitor.config.json", "utf8")).appId;
const javaDir = path.join("android/app/src/main/java", ...appId.split("."));
fs.mkdirSync(javaDir, { recursive: true });
fs.readdirSync("android-src").filter(f => f.endsWith(".java")).forEach(f => {
  const src = fs.readFileSync(path.join("android-src", f), "utf8").split("__PKG__").join(appId);
  fs.writeFileSync(path.join(javaDir, f), src);
});

// 3) AndroidManifest: الصلاحيات + الخدمة + المستقبِلات
const mf = "android/app/src/main/AndroidManifest.xml";
let x = fs.readFileSync(mf, "utf8");
["POST_NOTIFICATIONS", "SCHEDULE_EXACT_ALARM", "USE_EXACT_ALARM", "RECEIVE_BOOT_COMPLETED", "ACCESS_FINE_LOCATION",
 "ACCESS_COARSE_LOCATION", "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_MEDIA_PLAYBACK", "WAKE_LOCK", "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS"].forEach(p => {
  if (!x.includes('android.permission.' + p + '"'))
    x = x.replace("<application", '<uses-permission android:name="android.permission.' + p + '"/><application');
});
if (!x.includes("AdhanService")) {
  const comps =
    '<service android:name="' + appId + '.AdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>' +
    '<receiver android:name="' + appId + '.AdhanReceiver" android:exported="false"/>' +
    '<receiver android:name="' + appId + '.AdhanBootReceiver" android:exported="true"><intent-filter>' +
    '<action android:name="android.intent.action.BOOT_COMPLETED"/>' +
    '<action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>' +
    '<action android:name="android.intent.action.TIME_SET"/>' +
    '<action android:name="android.intent.action.TIMEZONE_CHANGED"/>' +
    '</intent-filter></receiver>';
  x = x.replace("</application>", comps + "</application>");
}
fs.writeFileSync(mf, x);
console.log("patched");

// 4) تنزيل خط المصحف (خط مجمع الملك فهد - حفص) ونص القرآن كاملاً وتضمينهما داخل التطبيق (للعمل دون إنترنت)
const QC = [7,286,200,176,120,165,206,75,129,109,123,111,43,52,99,128,111,110,98,135,112,78,118,64,77,227,93,88,69,60,34,30,73,54,45,83,182,88,75,85,54,53,89,59,37,35,38,29,18,45,60,49,62,55,78,96,29,22,24,13,14,11,11,18,12,12,30,52,52,44,28,28,20,56,40,31,50,40,46,42,29,19,36,25,22,17,19,26,30,20,15,21,11,8,8,19,5,8,8,11,11,8,3,9,5,4,7,3,6,3,5,4,5,6];
const base = w => w.replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g, "");
async function get(url) { const r = await fetch(url); if (!r.ok) throw new Error(url + " -> " + r.status); return r; }
(async () => {
  try {
    fs.mkdirSync("www/fonts", { recursive: true });
    const r = await get("https://cdn.jsdelivr.net/gh/thetruetruth/quran-data-kfgqpc@main/hafs/font/hafs.18.woff2");
    fs.writeFileSync("www/fonts/UthmanicHafs.woff2", Buffer.from(await r.arrayBuffer()));
    console.log("font downloaded");
  } catch (e) { console.log("font skipped:", e.message); }
  try {
    const j = await (await get("https://api.alquran.cloud/v1/quran/quran-uthmani")).json();
    const out = j.data.surahs.map((s, i) => {
      const n = i + 1, t = s.ayahs.map(a => a.text);
      if (n !== 1 && n !== 9) { const w = t[0].trim().split(" "); if (w.length > 4 && base(w[0]) === "بسم") t[0] = w.slice(4).join(" "); }
      return t;
    });
    if (out.length !== 114 || out.some((t, i) => t.length !== QC[i])) throw new Error("unexpected Quran structure");
    fs.writeFileSync("www/quran.json", JSON.stringify(out));
    console.log("quran downloaded");
  } catch (e) { console.log("quran skipped:", e.message); }
})();

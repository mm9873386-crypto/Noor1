package __PKG__;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;

public class AdhanReceiver extends BroadcastReceiver {
    static final String ACT_YES = "__PKG__.PRAYED_YES";
    static final String ACT_NO = "__PKG__.PRAYED_NO";
    static final String CH_FOLLOW = "noor_follow_v1";
    static final int NID_FOLLOW = 4712;
    static final int NID_HADITH = 4713;

    static final String[] HADITH = new String[] {
        "قال النبي \uFDFA: \u00ABمَنْ نَسِيَ صَلَاةً فَلْيُصَلِّ إِذَا ذَكَرَهَا، لَا كَفَّارَةَ لَهَا إِلَّا ذَلِكَ\u00BB \u2014 متفق عليه",
        "سُئل النبي \uFDFA: أيُّ العمل أحبُّ إلى الله؟ قال: \u00ABالصَّلَاةُ عَلَى وَقْتِهَا\u00BB \u2014 متفق عليه",
        "قال النبي \uFDFA: \u00ABأَرَأَيْتُمْ لَوْ أَنَّ نَهَرًا بِبَابِ أَحَدِكُمْ يَغْتَسِلُ فِيهِ كُلَّ يَوْمٍ خَمْسَ مَرَّاتٍ، هَلْ يَبْقَى مِنْ دَرَنِهِ شَيْءٌ؟\u00BB قالوا: لا يبقى. قال: \u00ABفَذَلِكَ مَثَلُ الصَّلَوَاتِ الْخَمْسِ، يَمْحُو اللَّهُ بِهِنَّ الْخَطَايَا\u00BB \u2014 متفق عليه",
        "قال النبي \uFDFA: \u00ABأَوَّلُ مَا يُحَاسَبُ بِهِ الْعَبْدُ يَوْمَ الْقِيَامَةِ مِنْ عَمَلِهِ صَلَاتُهُ، فَإِنْ صَلَحَتْ فَقَدْ أَفْلَحَ وَأَنْجَحَ\u00BB \u2014 رواه الترمذي والنسائي",
        "قال النبي \uFDFA: \u00ABالصَّلَوَاتُ الْخَمْسُ، وَالْجُمُعَةُ إِلَى الْجُمُعَةِ، كَفَّارَاتٌ لِمَا بَيْنَهُنَّ مَا لَمْ تُغْشَ الْكَبَائِرُ\u00BB \u2014 رواه مسلم",
        "قال النبي \uFDFA: \u00ABمَنْ صَلَّى الْبَرْدَيْنِ دَخَلَ الْجَنَّةَ\u00BB \u2014 متفق عليه",
        "قال النبي \uFDFA: \u00ABجُعِلَتْ قُرَّةُ عَيْنِي فِي الصَّلَاةِ\u00BB \u2014 رواه النسائي",
        "قال النبي \uFDFA: \u00ABرَكْعَتَا الْفَجْرِ خَيْرٌ مِنَ الدُّنْيَا وَمَا فِيهَا\u00BB \u2014 رواه مسلم"
    };

    @Override
    public void onReceive(Context c, Intent in) {
        String a = in.getAction();
        if (a == null) return;
        if (a.equals(AdhanService.ACT_STOP)) {
            c.stopService(new Intent(c, AdhanService.class));
            return;
        }
        if (a.equals(ACT_YES)) {
            cancel(c, NID_FOLLOW);
            return;
        }
        if (a.equals(ACT_NO)) {
            cancel(c, NID_FOLLOW);
            showHadith(c);
            return;
        }
        if (a.equals(AdhanScheduler.ACT)) {
            String kind = in.getStringExtra("kind");
            if ("follow".equals(kind)) {
                showFollow(c, in.getStringExtra("title"), in.getStringExtra("body"));
                return;
            }
            Intent s = new Intent(c, AdhanService.class);
            s.putExtra("title", in.getStringExtra("title"));
            s.putExtra("body", in.getStringExtra("body"));
            s.putExtra("sound", in.getStringExtra("sound"));
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    c.startForegroundService(s);
                } else {
                    c.startService(s);
                }
            } catch (Exception e) {
                // ignore
            }
        }
    }

    static void cancel(Context c, int id) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id);
    }

    static void ensureFollowChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CH_FOLLOW, "متابعة الصلاة", NotificationManager.IMPORTANCE_HIGH);
            ch.enableVibration(true);
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(ch);
        }
    }

    static int icon(Context c) {
        int r = c.getResources().getIdentifier("ic_stat_noor", "drawable", c.getPackageName());
        return r != 0 ? r : android.R.drawable.ic_dialog_info;
    }

    static PendingIntent pi(Context c, int code, String action) {
        Intent i = new Intent(c, AdhanReceiver.class);
        i.setAction(action);
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, code, i, f);
    }

    static PendingIntent openApp(Context c) {
        Intent open = c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
        if (open == null) return null;
        int f = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) f |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(c, 0, open, f);
    }

    static void showFollow(Context c, String title, String body) {
        try {
            ensureFollowChannel(c);
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_FOLLOW)
                    .setSmallIcon(icon(c))
                    .setContentTitle(title == null || title.length() == 0 ? "هل صليت الآن؟" : title)
                    .setContentText(body == null ? "" : body)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .addAction(android.R.drawable.checkbox_on_background, "\u2705 نعم صليت", pi(c, 21, ACT_YES))
                    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "\u274C لا لم أصلِّ", pi(c, 22, ACT_NO));
            PendingIntent o = openApp(c);
            if (o != null) b.setContentIntent(o);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NID_FOLLOW, b.build());
        } catch (Exception e) {
            // ignore
        }
    }

    static void showHadith(Context c) {
        try {
            ensureFollowChannel(c);
            String h = HADITH[(int) ((System.currentTimeMillis() / 60000L) % HADITH.length)];
            NotificationCompat.Builder b = new NotificationCompat.Builder(c, CH_FOLLOW)
                    .setSmallIcon(icon(c))
                    .setContentTitle("قم إلى الصلاة \uD83E\uDD32")
                    .setContentText(h)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(h))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setDefaults(NotificationCompat.DEFAULT_ALL)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true);
            PendingIntent o = openApp(c);
            if (o != null) b.setContentIntent(o);
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NID_HADITH, b.build());
        } catch (Exception e) {
            // ignore
        }
    }
}
